import Image from "next/image"

export default function CreatorSection() {
  return (
    <section className="py-20 bg-blue-950">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 items-center">
            <div className="md:col-span-1">
              <div className="relative h-80 w-full rounded-lg overflow-hidden border-2 border-yellow-400">
                <Image src="/placeholder.svg?height=600&width=400" alt="Eiichiro Oda" fill className="object-cover" />
              </div>
            </div>

            <div className="md:col-span-2 space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold text-yellow-400">Eiichiro Oda</h2>
              <h3 className="text-xl text-white">Creator of One Piece</h3>

              <div className="space-y-4 text-gray-200">
                <p>
                  <span className="font-bold text-white">Born:</span> January 1, 1975, in Kumamoto, Japan.
                </p>
                <p>
                  <span className="font-bold text-white">Profession:</span> Manga artist and storyteller.
                </p>

                <p>
                  From a young age, Eiichiro Oda dreamed of becoming a manga artist. Inspired by Akira Toriyama's Dragon
                  Ball and pirates like those in Vicky the Viking, he began creating stories and characters early in
                  life.
                </p>

                <p>
                  At age 17, Oda submitted his work Wanted! and won several awards, catching the attention of Weekly
                  Shonen Jump. He then worked as an assistant on popular manga like Rurouni Kenshin.
                </p>

                <p>
                  In 1997, he launched One Piece, the story of Monkey D. Luffy and his quest to find the One Piece and
                  become Pirate King. It quickly became a cultural phenomenon, breaking records and spanning manga,
                  anime, films, and games.
                </p>

                <p>
                  As of 2025, One Piece is one of the best-selling manga of all time, with Oda still leading the story
                  toward its epic finale.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
