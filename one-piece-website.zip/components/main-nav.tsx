"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, Map, Users, Ship } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export default function MainNav() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled ? "bg-blue-950/90 backdrop-blur-md py-2 shadow-lg" : "bg-transparent py-4",
      )}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Image src="/placeholder.svg?height=40&width=40" alt="Straw Hat Pirates Logo" width={40} height={40} />
            <span className="font-bold text-xl text-white hidden sm:inline-block">Straw Hat Pirates</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <NavLink href="/" icon={<Ship className="h-4 w-4" />}>
              Home
            </NavLink>
            <NavLink href="/crew" icon={<Users className="h-4 w-4" />}>
              The Crew
            </NavLink>
            <NavLink href="/journey" icon={<Map className="h-4 w-4" />}>
              Journey
            </NavLink>
            <NavLink href="/ship" icon={<Ship className="h-4 w-4" />}>
              The Ships
            </NavLink>
          </nav>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white hover:bg-blue-800/50"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-blue-900 border-t border-blue-800">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <MobileNavLink href="/" icon={<Ship className="h-5 w-5" />}>
              Home
            </MobileNavLink>
            <MobileNavLink href="/crew" icon={<Users className="h-5 w-5" />}>
              The Crew
            </MobileNavLink>
            <MobileNavLink href="/journey" icon={<Map className="h-5 w-5" />}>
              Journey
            </MobileNavLink>
            <MobileNavLink href="/ship" icon={<Ship className="h-5 w-5" />}>
              The Ships
            </MobileNavLink>
          </div>
        </div>
      )}
    </header>
  )
}

interface NavLinkProps {
  href: string
  children: React.ReactNode
  icon?: React.ReactNode
}

function NavLink({ href, children, icon }: NavLinkProps) {
  return (
    <Link
      href={href}
      className="text-gray-200 hover:text-yellow-400 transition-colors flex items-center gap-1.5 text-sm font-medium"
    >
      {icon}
      {children}
    </Link>
  )
}

function MobileNavLink({ href, children, icon }: NavLinkProps) {
  return (
    <Link
      href={href}
      className="text-white hover:text-yellow-400 transition-colors flex items-center gap-3 text-lg font-medium p-2 rounded-md hover:bg-blue-800/50"
    >
      {icon}
      {children}
    </Link>
  )
}
