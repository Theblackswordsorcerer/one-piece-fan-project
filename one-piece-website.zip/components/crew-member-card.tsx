"use client"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Info, X } from "lucide-react"
import type { CrewMember } from "@/lib/types"

interface CrewMemberCardProps {
  member: CrewMember
}

export default function CrewMemberCard({ member }: CrewMemberCardProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <motion.div
        className="bg-blue-800/50 backdrop-blur-sm rounded-lg overflow-hidden border border-blue-700 hover:border-yellow-400 transition-all duration-300 cursor-pointer group"
        whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(59, 130, 246, 0.5)" }}
        onClick={() => setIsOpen(true)}
      >
        <div className="relative h-64 overflow-hidden">
          <Image
            src={member.image || "/placeholder.svg"}
            alt={member.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-900 to-transparent h-1/2"></div>
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-xl font-bold text-white">{member.name}</h3>
            <p className="text-yellow-400">{member.role}</p>
          </div>
        </div>
        <div className="p-4">
          <div className="flex justify-between items-center mb-3">
            <div className="text-sm text-gray-300">Bounty:</div>
            <div className="text-sm font-bold text-yellow-400">{member.bounty} Berries</div>
          </div>
          <Button
            variant="ghost"
            className="w-full border border-blue-600 text-white hover:bg-blue-700 hover:text-white"
            onClick={() => setIsOpen(true)}
          >
            <Info className="mr-2 h-4 w-4" />
            View Details
          </Button>
        </div>
      </motion.div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-3xl bg-gradient-to-b from-blue-900 to-blue-950 border-blue-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-yellow-400 flex items-center">
              {member.name}
              <span className="ml-2 text-sm bg-red-600 text-white px-2 py-0.5 rounded-full">{member.role}</span>
            </DialogTitle>
            <DialogDescription className="text-gray-300">
              First Appearance: Chapter {member.firstAppearance}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="relative h-80 md:h-full rounded-lg overflow-hidden border border-blue-700">
              <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
            </div>

            <div className="md:col-span-2 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-800/50 p-3 rounded-lg">
                  <div className="text-sm text-gray-300">Birthday</div>
                  <div className="font-medium">{member.birthday}</div>
                </div>
                <div className="bg-blue-800/50 p-3 rounded-lg">
                  <div className="text-sm text-gray-300">Age</div>
                  <div className="font-medium">{member.age} (post-timeskip)</div>
                </div>
                <div className="bg-blue-800/50 p-3 rounded-lg">
                  <div className="text-sm text-gray-300">Height</div>
                  <div className="font-medium">{member.height}</div>
                </div>
                <div className="bg-blue-800/50 p-3 rounded-lg">
                  <div className="text-sm text-gray-300">Devil Fruit</div>
                  <div className="font-medium">{member.devilFruit || "None"}</div>
                </div>
              </div>

              <div className="bg-blue-800/30 p-4 rounded-lg">
                <h4 className="text-lg font-bold mb-2 text-yellow-400">Bounty</h4>
                <div className="text-2xl font-bold">{member.bounty} Berries</div>
              </div>

              <div>
                <h4 className="text-lg font-bold mb-2 text-yellow-400">Backstory</h4>
                <p className="text-gray-300">{member.backstory}</p>
              </div>
            </div>
          </div>

          <Button
            variant="ghost"
            className="absolute top-2 right-2 rounded-full h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-blue-800"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        </DialogContent>
      </Dialog>
    </>
  )
}
