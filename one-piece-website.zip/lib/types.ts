export interface CrewMember {
  id: number
  name: string
  role: string
  firstAppearance: string
  birthday: string
  age: number
  height: string
  devilFruit: string | null
  bounty: string
  backstory: string
  image: string
}
