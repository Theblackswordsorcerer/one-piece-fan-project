import Image from "next/image"
import { Anchor, ShipIcon } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ShipPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-950 to-blue-900">
      {/* Hero Section */}
      <section className="relative h-[50vh] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/thousand-sunny.png"
            alt="The Straw Hat Pirates' Ships"
            fill
            className="object-cover opacity-40"
            priority
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-blue-950 to-transparent z-10" />

        <div className="container relative z-20 mx-auto px-4 h-full flex flex-col justify-center items-center text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg">
            The <span className="text-yellow-400">Ships</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 max-w-3xl">
            The vessels that carried the Straw Hat Pirates on their journey
          </p>
        </div>
      </section>

      {/* Ships Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="merry" className="max-w-5xl mx-auto">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="merry" className="text-lg py-3">
                <div className="flex items-center gap-2">
                  <ShipIcon className="h-5 w-5" />
                  <span>Going Merry</span>
                </div>
              </TabsTrigger>
              <TabsTrigger value="sunny" className="text-lg py-3">
                <div className="flex items-center gap-2">
                  <Anchor className="h-5 w-5" />
                  <span>Thousand Sunny</span>
                </div>
              </TabsTrigger>
            </TabsList>

            {/* Going Merry Content */}
            <TabsContent value="merry" className="mt-0">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="relative h-[400px] rounded-lg overflow-hidden border-2 border-yellow-400">
                  <Image src="/placeholder.svg?height=600&width=800" alt="Going Merry" fill className="object-cover" />
                </div>
                <div className="space-y-6">
                  <Card className="bg-blue-900/50 border-blue-700">
                    <CardHeader>
                      <CardTitle className="text-yellow-400">The Going Merry</CardTitle>
                      <CardDescription className="text-gray-300">
                        The first ship of the Straw Hat Pirates
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="text-gray-200">
                      <p>
                        The Going Merry was the first ship that the Straw Hat Pirates sailed on. It was given to them by
                        Kaya, a wealthy girl from Syrup Village, after they helped her and her village against the
                        pirate Kuro.
                      </p>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-2 gap-4">
                    <Card className="bg-blue-900/50 border-blue-700">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm text-yellow-400">Size</CardTitle>
                      </CardHeader>
                      <CardContent className="text-gray-200">
                        <p>Length: ~20 meters (66 feet)</p>
                        <p>Width: ~10 meters (33 feet)</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-blue-900/50 border-blue-700">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm text-yellow-400">Appearance</CardTitle>
                      </CardHeader>
                      <CardContent className="text-gray-200">
                        <p>Ram's head at the bow, wooden ship with a colorful, whimsical design</p>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="bg-blue-900/50 border-blue-700">
                    <CardHeader>
                      <CardTitle className="text-yellow-400">Key Events</CardTitle>
                    </CardHeader>
                    <CardContent className="text-gray-200 space-y-2">
                      <p>
                        <span className="font-bold">First Major Journey:</span> The Going Merry carried the crew through
                        their early adventures in the East Blue, Alabasta, Skypiea, Water 7, and more.
                      </p>
                      <p>
                        <span className="font-bold">Final Voyage:</span> After facing heavy damage during the Enies
                        Lobby arc, the ship's condition worsened, and despite multiple repairs, it was ultimately deemed
                        irreparable. In the Enies Lobby Arc, it sacrificed itself to protect the crew and was sent off
                        in an emotional farewell.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="mt-8 bg-blue-900/30 p-6 rounded-lg border border-blue-700">
                <h3 className="text-xl font-bold text-yellow-400 mb-4">The Spirit of Merry</h3>
                <p className="text-gray-200 mb-4">
                  The Going Merry was portrayed as having a soul of its own. This was later confirmed in the Water 7 Arc
                  when it was revealed that the ship had developed a "spirit," a reflection of the bond between the crew
                  and their ship.
                </p>
                <p className="text-gray-200">
                  The Going Merry's sacrifice and funeral is considered one of the most emotional moments in the One
                  Piece series, showing how the ship was truly considered a member of the crew.
                </p>
              </div>
            </TabsContent>

            {/* Thousand Sunny Content */}
            <TabsContent value="sunny" className="mt-0">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="relative h-[400px] rounded-lg overflow-hidden border-2 border-yellow-400">
                  <Image src="/images/thousand-sunny.png" alt="Thousand Sunny" fill className="object-cover" />
                </div>
                <div className="space-y-6">
                  <Card className="bg-blue-900/50 border-blue-700">
                    <CardHeader>
                      <CardTitle className="text-yellow-400">The Thousand Sunny</CardTitle>
                      <CardDescription className="text-gray-300">
                        The second ship of the Straw Hat Pirates
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="text-gray-200">
                      <p>
                        The Thousand Sunny was built after the Going Merry was no longer seaworthy. The ship was
                        designed and built by Franky, the Straw Hat's shipwright, with the help of the Galley-La
                        Company. It was named after Luffy's dream of reaching the Grand Line and a homage to the crew's
                        journey to find the One Piece.
                      </p>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-2 gap-4">
                    <Card className="bg-blue-900/50 border-blue-700">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm text-yellow-400">Size</CardTitle>
                      </CardHeader>
                      <CardContent className="text-gray-200">
                        <p>Length: ~39 meters (128 feet)</p>
                        <p>Width: ~26 meters (85 feet)</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-blue-900/50 border-blue-700">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm text-yellow-400">Appearance</CardTitle>
                      </CardHeader>
                      <CardContent className="text-gray-200">
                        <p>Lion head at the bow, larger and more complex design than the Going Merry</p>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="bg-blue-900/50 border-blue-700">
                    <CardHeader>
                      <CardTitle className="text-yellow-400">Key Events</CardTitle>
                    </CardHeader>
                    <CardContent className="text-gray-200 space-y-2">
                      <p>
                        <span className="font-bold">First Major Voyage:</span> The Thousand Sunny first appeared in the
                        Enies Lobby Arc and has since sailed with the crew through their many adventures in the Grand
                        Line.
                      </p>
                      <p>
                        <span className="font-bold">Crucial Battles:</span> It was heavily involved in the Marineford
                        War and subsequent adventures, withstanding powerful attacks and ensuring the crew's survival.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="mt-8 bg-blue-900/30 p-6 rounded-lg border border-blue-700">
                <h3 className="text-xl font-bold text-yellow-400 mb-4">Special Features</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-bold text-white mb-2">The Going Merry's Legacy</h4>
                    <p className="text-gray-200">
                      Franky incorporated parts of the Going Merry's remains into the Thousand Sunny, symbolizing the
                      crew's respect and love for their first ship.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-2">Sunny's Deck</h4>
                    <p className="text-gray-200">
                      A larger, more spacious deck that accommodates various features like a garden, aquarium, and
                      weaponry.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-2">Weaponry</h4>
                    <p className="text-gray-200">
                      The ship is equipped with powerful weapons like the Coup de Burst, a rocket-powered booster, and
                      other artillery for offense and defense.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-2">Accommodations</h4>
                    <p className="text-gray-200">
                      The ship includes separate rooms for each crew member, a kitchen, and a mechanical room.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-2">Mini Merry 2</h4>
                    <p className="text-gray-200">
                      A small boat created in honor of the Going Merry, which is always ready for emergencies.
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}
