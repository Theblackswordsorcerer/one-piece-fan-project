import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import MainNav from "@/components/main-nav"
import { Instagram } from "lucide-react"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Straw Hat Pirates | One Piece",
  description:
    "Join the adventure with Monkey D. Luffy and his crew as they sail across the Grand Line in search of the One Piece!",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark">
          <MainNav />
          <main className="pt-16">{children}</main>
          <footer className="bg-blue-950 border-t border-blue-900 py-8 relative">
            <div className="container mx-auto px-4 text-center text-gray-400">
              <p className="text-sm">© {new Date().getFullYear()} Straw Hat Pirates. This is a fan-made website.</p>
              <p className="text-xs mt-2">
                One Piece and all related characters are property of Eiichiro Oda and Shueisha Inc.
              </p>
            </div>

            {/* Instagram and Alias */}
            <div className="absolute bottom-2 right-4 flex items-center gap-1 text-xs text-gray-400">
              <span className="font-light">Winter_halo</span>
              <a
                href="https://instagram.com/otaku_extraordinaire"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 hover:text-yellow-400 transition-colors"
              >
                <Instagram className="h-3 w-3" />
                <span>otaku_extraordinaire</span>
              </a>
            </div>
          </footer>
        </ThemeProvider>
      </body>
    </html>
  )
}
