import Image from "next/image"
import { Anchor, Map, Skull } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function JourneyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-950 to-blue-900">
      {/* Hero Section */}
      <section className="relative h-[50vh] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="The Straw Hat Pirates' Journey"
            fill
            className="object-cover opacity-40"
            priority
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-blue-950 to-transparent z-10" />

        <div className="container relative z-20 mx-auto px-4 h-full flex flex-col justify-center items-center text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg">
            The <span className="text-yellow-400">Journey</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 max-w-3xl">
            Follow the adventures of the Straw Hat Pirates across the seas
          </p>
        </div>
      </section>

      {/* Journey Timeline */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="w-full space-y-6">
              {/* East Blue Saga */}
              <AccordionItem
                value="east-blue"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Skull className="h-6 w-6 text-white" />
                    </div>
                    <span>East Blue Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Romance Dawn Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy sets out to become Pirate King, recruits Zoro, and faces Alvida.
                      </p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Orange Town Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy and crew fight Buggy the Clown and recruit Nami.</p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Syrup Village Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy and crew meet Usopp and help defend his village.</p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Baratie Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy recruits Sanji after defeating Don Krieg and Mihawk.</p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Arlong Park Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy defeats Arlong and frees Nami from his rule.</p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Loguetown Arc</h3>
                      <p className="text-gray-300 mt-1">The crew visits the town where Gol D. Roger was executed.</p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Alabasta Saga */}
              <AccordionItem
                value="alabasta"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Map className="h-6 w-6 text-white" />
                    </div>
                    <span>Alabasta Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Reverse Mountain Arc</h3>
                      <p className="text-gray-300 mt-1">The crew enters the Grand Line and meets Laboon.</p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Whiskey Peak Arc</h3>
                      <p className="text-gray-300 mt-1">
                        The crew faces the Baroque Works and learns of Crocodile's plans.
                      </p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Little Garden Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy and crew meet giants and learn of the island's history.
                      </p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Drum Island Arc</h3>
                      <p className="text-gray-300 mt-1">
                        The crew meets Chopper and defeats Wapol, making Chopper a crew member.
                      </p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Alabasta Arc</h3>
                      <p className="text-gray-300 mt-1">
                        The crew defeats Crocodile and helps Princess Vivi save Alabasta.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Sky Island Saga */}
              <AccordionItem
                value="sky-island"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Anchor className="h-6 w-6 text-white" />
                    </div>
                    <span>Sky Island Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Jaya Arc</h3>
                      <p className="text-gray-300 mt-1">The crew learns about Skypiea and meets Blackbeard.</p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Skypiea Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy and crew defeat Enel and restore peace to Skypiea.</p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Water 7 Saga */}
              <AccordionItem
                value="water-7"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Skull className="h-6 w-6 text-white" />
                    </div>
                    <span>Water 7 Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Water 7 Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy's crew faces betrayal and conflict with the CP9, leading to Franky joining the crew.
                      </p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Enies Lobby Arc</h3>
                      <p className="text-gray-300 mt-1">
                        The crew declares war on the World Government to rescue Nico Robin.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Thriller Bark Saga */}
              <AccordionItem
                value="thriller-bark"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Skull className="h-6 w-6 text-white" />
                    </div>
                    <span>Thriller Bark Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Thriller Bark Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy and crew face Gecko Moria and add Brook to the crew.</p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Sabaody Archipelago Saga */}
              <AccordionItem
                value="sabaody"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Map className="h-6 w-6 text-white" />
                    </div>
                    <span>Sabaody Archipelago Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Sabaody Archipelago Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy and crew meet the Supernovas and face a World Government crackdown. The crew is separated
                        by Bartholomew Kuma.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Impel Down Saga */}
              <AccordionItem
                value="impel-down"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Anchor className="h-6 w-6 text-white" />
                    </div>
                    <span>Impel Down Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Impel Down Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy breaks into the prison to rescue his brother, Ace.</p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Marineford Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy and allies fight to save Ace, but Ace dies, and Luffy is devastated.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Post-War Saga */}
              <AccordionItem
                value="post-war"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Skull className="h-6 w-6 text-white" />
                    </div>
                    <span>Post-War Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Post-Marineford Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy and crew train for two years and prepare to reunite.</p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Fish-Man Island Saga */}
              <AccordionItem
                value="fishman-island"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Map className="h-6 w-6 text-white" />
                    </div>
                    <span>Fish-Man Island Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Fish-Man Island Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy and crew defeat the New Fish-Man Pirates and Hody Jones.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Dressrosa Saga */}
              <AccordionItem
                value="dressrosa"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Anchor className="h-6 w-6 text-white" />
                    </div>
                    <span>Dressrosa Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Punk Hazard Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy and Law form an alliance to take down Kaido and fight Caesar Clown.
                      </p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Dressrosa Arc</h3>
                      <p className="text-gray-300 mt-1">
                        The crew defeats Donquixote Doflamingo and helps the people of Dressrosa.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Whole Cake Island Saga */}
              <AccordionItem
                value="whole-cake"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Map className="h-6 w-6 text-white" />
                    </div>
                    <span>Whole Cake Island Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Zou Arc</h3>
                      <p className="text-gray-300 mt-1">
                        The crew uncovers the secrets of the Mink Tribe and the Road Poneglyphs.
                      </p>
                    </div>
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Whole Cake Island Arc</h3>
                      <p className="text-gray-300 mt-1">Luffy and crew fight Big Mom and rescue Sanji.</p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Wano Country Saga */}
              <AccordionItem value="wano" className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden">
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Skull className="h-6 w-6 text-white" />
                    </div>
                    <span>Wano Country Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Wano Country Arc</h3>
                      <p className="text-gray-300 mt-1">
                        Luffy and allies fight against Kaido and Big Mom to free Wano. This arc is one of the most
                        important in the series.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Egghead Island Saga */}
              <AccordionItem
                value="egghead"
                className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Anchor className="h-6 w-6 text-white" />
                    </div>
                    <span>Egghead Island Saga</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Egghead Island Arc</h3>
                      <p className="text-gray-300 mt-1">
                        The crew arrives at Egghead Island, where they face the futuristic island's secrets, including
                        battles with the powerful Marines and the ongoing clash with the World Government. This arc
                        delves into the mysteries of the ancient weapons and the ties to Vegapunk, the island's
                        scientist.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Final Saga */}
              <AccordionItem value="final" className="border border-blue-700 rounded-lg bg-blue-900/50 overflow-hidden">
                <AccordionTrigger className="px-6 py-4 hover:bg-blue-800/50 text-xl font-bold text-yellow-400">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-600 p-2 rounded-full">
                      <Map className="h-6 w-6 text-white" />
                    </div>
                    <span>Final Saga (Ongoing)</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 text-gray-200">
                  <div className="space-y-6">
                    <div className="border-l-4 border-yellow-400 pl-4 py-2">
                      <h3 className="text-lg font-bold text-white">Final Saga</h3>
                      <p className="text-gray-300 mt-1">
                        The manga is currently entering its Final Saga, with new developments happening rapidly. The
                        story revolves around Luffy's final battles, the true history of the world, the secrets behind
                        the Void Century, and the ancient weapons. The Straw Hat Pirates' journey is heading towards the
                        ultimate confrontation with the world's strongest powers.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>
    </div>
  )
}
