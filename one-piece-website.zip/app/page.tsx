import Image from "next/image"
import { Anchor, Ship, Skull } from "lucide-react"
import { Button } from "@/components/ui/button"
import CrewMemberCard from "@/components/crew-member-card"
import { crewMembers } from "@/lib/crew-data"
import CreatorSection from "@/components/creator-section"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-950 to-blue-900">
      {/* Hero Section */}
      <section className="relative h-[80vh] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/strawhat-bg.png"
            alt="Straw Hat Pirates Jolly Rogers"
            fill
            className="object-cover opacity-40"
            priority
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-blue-950 to-transparent z-10" />

        <div className="container relative z-20 mx-auto px-4 h-full flex flex-col justify-center items-center text-center">
          <div className="animate-float">
            <Image
              src="/images/strawhat-bg.png"
              alt="Straw Hat Pirates Logo"
              width={200}
              height={200}
              className="mx-auto mb-8"
            />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg">
            <span className="text-yellow-400">STRAW HAT</span> PIRATES
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mb-8">
            Join the adventure with Monkey D. Luffy and his crew as they sail across the Grand Line in search of the One
            Piece!
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
              Meet The Crew
              <Ship className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="border-yellow-400 text-yellow-400 hover:bg-yellow-400/10">
              Ship Log
              <Anchor className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Crew Overview Section */}
      <section className="py-20 bg-[url('/images/strawhat-bg.png')] bg-fixed bg-cover bg-center relative">
        <div className="absolute inset-0 bg-blue-950/80 backdrop-blur-sm"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center mb-4">
              <div className="h-0.5 w-12 bg-yellow-400"></div>
              <Skull className="mx-4 text-yellow-400 h-8 w-8" />
              <div className="h-0.5 w-12 bg-yellow-400"></div>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">The Legendary Crew</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Meet the extraordinary pirates who sail under the Straw Hat flag, each with their unique abilities and
              dreams.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {crewMembers.map((member) => (
              <CrewMemberCard key={member.id} member={member} />
            ))}
          </div>
        </div>
      </section>

      {/* Creator Section */}
      <CreatorSection />

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-red-700 to-red-900">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">The Greatest Adventure Awaits!</h2>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto mb-8">
            Explore the Grand Line, discover the mysteries of the Poneglyphs, and follow the adventure to find the One
            Piece!
          </p>
        </div>
      </section>
    </div>
  )
}
